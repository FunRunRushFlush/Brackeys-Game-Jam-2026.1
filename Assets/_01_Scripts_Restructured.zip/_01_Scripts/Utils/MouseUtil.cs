using UnityEngine;

public static class MouseUtil 
{
    private static Camera _mainCamera = Camera.main;
    public static Vector3 GetWorldMousePositionInWorldSpace(float zValue = 0f)
    {
        Plane plane = new Plane(_mainCamera.transform.forward, new Vector3(0, 0, zValue));
        Ray ray = _mainCamera.ScreenPointToRay(Input.mousePosition);
        if(plane.Raycast(ray, out float distance))
        {
            return ray.GetPoint(distance);
        }

        Debug.LogError("MouseUtil.GetWorldMousePositionInWorldSpace: Could not raycast to plane.");
        return Vector3.zero;
    }
}
