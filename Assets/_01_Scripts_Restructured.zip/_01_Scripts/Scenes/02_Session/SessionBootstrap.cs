using UnityEngine;

public class SessionBootstrap : MonoBehaviour
{
    [SerializeField] RunState run;
    [SerializeField] LootService loot;

    void Awake()
    {
        CoreManager.Instance.RegisterSession(run, loot);
    }

    void OnDestroy()
    {
        if (CoreManager.Instance != null)
        {
            CoreManager.Instance.ClearSession();
        }
    }
}
