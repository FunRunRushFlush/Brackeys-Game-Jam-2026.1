using System.Collections;
using UnityEngine;

public class GameOverManager : MonoBehaviour
{
    public void BackToMainMenu()
    {
        GameFlowController.Current.BackToMainMenu();
    }

    public void BuyItem(int goldCost)
    {

    }

}