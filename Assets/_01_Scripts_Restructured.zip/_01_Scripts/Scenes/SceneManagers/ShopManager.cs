using System.Collections;
using UnityEngine;

public class ShopManager : MonoBehaviour
{
    public void SwitchToMCombat()
    {
        GameFlowController.Current.ChooseCombat();
    }
    public void SwitchToShop()
    {
        GameFlowController.Current.ChooseShop();
    }

    public void LeaveShop()
    {
        GameFlowController.Current.ShopLeave();
    }
}