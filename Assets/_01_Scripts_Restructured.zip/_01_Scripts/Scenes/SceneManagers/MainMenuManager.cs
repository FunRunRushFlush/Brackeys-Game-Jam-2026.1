using System.Collections;
using UnityEngine;

public class MainMenuManager : MonoBehaviour
{

    public void StartSession()
    {
        GameFlowController.Current.StartNewRun();
    }


}