using System.Collections;
using UnityEngine;

public class LootManager : MonoBehaviour
{
    public void PickLoot(int lootSlot)
    {
        //int gold = 10;
        //CoreManager.Instance.Run.ChangeAmountOfGold(gold*lootSlot);

        GameFlowController.Current.LootPicked(lootSlot);
    }

    public void Continue()
    {
        GameFlowController.Current.LootPicked(-1);
    }
}