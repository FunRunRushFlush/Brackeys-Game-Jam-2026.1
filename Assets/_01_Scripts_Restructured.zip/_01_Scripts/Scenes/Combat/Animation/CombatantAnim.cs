public enum CombatantAnim
{
    Idle,
    Attack,
    Hit,
    Die,
    Buff,
    Debuff
}

