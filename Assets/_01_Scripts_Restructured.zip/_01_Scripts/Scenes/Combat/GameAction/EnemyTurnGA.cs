using UnityEngine;

public class EnemyTurnGA : GameAction
{

}
