using System.Collections;
using UnityEngine;

public class CombatManager : MonoBehaviour
{
    public void CombatWon()
    {
        GameFlowController.Current.CombatWon();

    }
    public void CombatLost()
    {
        GameFlowController.Current.CombatLost();
    }
}