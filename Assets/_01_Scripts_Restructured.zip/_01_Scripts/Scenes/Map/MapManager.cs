using System.Collections;
using UnityEngine;

public class MapManager : MonoBehaviour
{
    public void SwitchToCombat()
    {
        GameFlowController.Current.ChooseCombat();
    }
    public void SwitchToShop()
    {
        GameFlowController.Current.ChooseShop();
    }

    public void SwitchToEvent()
    {
        GameFlowController.Current.ChooseEvent();
    }
}