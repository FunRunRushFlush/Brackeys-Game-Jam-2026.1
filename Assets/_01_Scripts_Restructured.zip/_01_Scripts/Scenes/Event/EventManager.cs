using System.Collections;
using UnityEngine;

public class EventManager : MonoBehaviour
{
    public void ChangeAmountOfGold(int goldAmount)
    {
        CoreManager.Instance.Run.ChangeAmountOfGold(goldAmount);
        EventComplete();
    }


    public void EventComplete()
    {
        GameFlowController.Current.EventComplete();
    }
}