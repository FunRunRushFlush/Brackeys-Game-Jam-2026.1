using UnityEngine;

public class CoreManager : MonoBehaviour
{
    public static CoreManager Instance { get; private set; }
    public RunState Run { get; private set; }
    public LootService Loot { get; private set; }

    void Awake()
    {
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void RegisterSession(RunState run, LootService loot)
    {
        Run = run;
        Loot = loot;
    }

    public void ClearSession()
    {
        Run = null;
        Loot = null;
    }

    void Start()
    {
        // Core Setup for the game
        // Load everything like AudioManagers, SaveSystem, InputControlSystem etc.

        SceneController.Current
            .NewTransition()
            .Load(SceneDatabase.Slots.Menu, SceneDatabase.Scenes.MainMenu)
            .WithOverlay()
            .Perform();

    }
}
