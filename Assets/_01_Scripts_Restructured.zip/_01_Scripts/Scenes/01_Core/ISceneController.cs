﻿using UnityEngine;

public interface ISceneController
{
    Coroutine ExecutePlan(SceneController.SceneTransitionPlan plan);
    void Load(string sceneName);
    SceneController.SceneTransitionPlan NewTransition();
}