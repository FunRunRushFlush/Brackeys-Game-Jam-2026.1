

public enum StatusEffectType
{
    ARMOR,
    BURN
}

