public enum CardTag
{
    Attack,
    Skill,
    Power
}
