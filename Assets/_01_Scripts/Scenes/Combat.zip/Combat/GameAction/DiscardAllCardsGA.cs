public class DiscardAllCardsGA : GameAction
{

}
