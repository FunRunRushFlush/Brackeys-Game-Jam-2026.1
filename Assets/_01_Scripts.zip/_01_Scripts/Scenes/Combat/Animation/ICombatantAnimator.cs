public interface ICombatantAnimator
{
    void Play(CombatantAnim anim);
    void SetIdle();
}
