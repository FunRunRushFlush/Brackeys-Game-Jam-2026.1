public class EnemyTurnGA : GameAction
{

}
