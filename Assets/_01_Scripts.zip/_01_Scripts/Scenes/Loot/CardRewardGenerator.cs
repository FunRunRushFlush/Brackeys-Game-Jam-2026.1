using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class CardRewardGenerator
{
    public static List<CardData> GenerateChoices(
        IReadOnlyList<CardData> pool,
        IReadOnlyList<CardData> playerDeck,
        BiomeType biome,
        int choiceCount = 3)
    {
        // Filter: null raus
        var candidates = pool.Where(c => c != null).ToList();
        if (candidates.Count == 0) 
            return new List<CardData>();

        // Build weights
        var weights = new List<float>(candidates.Count);
        for (int i = 0; i < candidates.Count; i++)
        {
            var card = candidates[i];
            float w = 1f;

            // Beispiel: Biome -> Tag Bonus (nur wenn du passende Tags hast)
            // if (card.Tags.Contains(CardTag.Fire) && biome == BiomeType.Fire) w += 2f;

            // Malus wenn schon im Deck (statt hard exclude)
            if (playerDeck != null && playerDeck.Contains(card)) w *= 0.25f;

            weights.Add(Mathf.Max(0.01f, w));
        }

        // Draw without replacement
        var result = new List<CardData>(choiceCount);
        for (int pick = 0; pick < choiceCount && candidates.Count > 0; pick++)
        {
            int idx = WeightedIndex(weights);
            result.Add(candidates[idx]);

            candidates.RemoveAt(idx);
            weights.RemoveAt(idx);
        }

        return result;
    }

    private static int WeightedIndex(List<float> weights)
    {
        float total = 0f;
        for (int i = 0; i < weights.Count; i++) total += weights[i];

        float r = Random.value * total;
        for (int i = 0; i < weights.Count; i++)
        {
            r -= weights[i];
            if (r <= 0f) return i;
        }
        return weights.Count - 1;
    }
}
