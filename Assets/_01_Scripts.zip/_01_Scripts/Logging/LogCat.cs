namespace Game.Logging
{
    public enum LogCat { General, Gameplay, UI, Net, Save, AI, Audio, Perf }
}
