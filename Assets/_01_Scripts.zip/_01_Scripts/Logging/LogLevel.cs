namespace Game.Logging
{
    public enum LogLevel { Trace, Debug, Info, Warning, Error, Fatal, None }
}
