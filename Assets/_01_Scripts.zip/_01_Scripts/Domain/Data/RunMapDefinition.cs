using System;
using System.Collections.Generic;
using UnityEngine;

public enum MapNodeType
{
    Combat,
    EliteCombat,
    Shop,
    Event,
    Boss
}

[Serializable]
public class MapNodeDefinition
{
    public MapNodeType type;

    // Optional: Overrides (f�r Jam super praktisch)
    public EncounterDefinition combatOverride; // f�r Combat/Elite (wenn gesetzt)
    public EncounterDefinition bossOverride;   // f�r Boss (wenn gesetzt)
}

[Serializable]
public class BiomeMapDefinition
{
    public BiomeType biome;
    public List<MapNodeDefinition> nodes;
}

[CreateAssetMenu(menuName = "Run/Run Map Definition")]
public class RunMapDefinition : ScriptableObject
{
    public List<BiomeMapDefinition> biomes;
}
