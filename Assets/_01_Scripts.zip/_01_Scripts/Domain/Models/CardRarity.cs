public enum CardRarity
{ 
    //Testing
    Admin,
    Starter,
    Common, 
    Uncommon, 
    Rare,
    Epic
}