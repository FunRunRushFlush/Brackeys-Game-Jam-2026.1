public enum ConditionSubject
{
    Caster,
    ManualTarget,
}