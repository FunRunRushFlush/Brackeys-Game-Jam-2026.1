

public enum StatusEffectType
{
    ARMOR,
    BURN,
    POISON,
    STRENGTH,
    WEAKNESS
}

